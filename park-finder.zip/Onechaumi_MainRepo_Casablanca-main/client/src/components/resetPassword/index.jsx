import React from 'react'
import ResetForm from './resetform'
import '../../css/resetpassword.css'


export default function Resetpassword() {


    return (
        <div className="container">
            <ResetForm />
        </div>
    )
}